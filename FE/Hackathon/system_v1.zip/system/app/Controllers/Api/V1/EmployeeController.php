<?php
declare(strict_types=1);

namespace App\Controllers\Api\V1;

use App\Core\Controller;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Validator;
use App\Models\Employee;

class EmployeeController extends Controller
{
    private Employee $employees;

    public function __construct()
    {
        $this->employees = new Employee();
    }

    public function index(Request $request): array
    {
        $paging = Paginator::resolve($request);
        $search = $request->query('q');
        $status = $request->query('status');
        $departmentId = $request->query('department_id') !== null ? (int) $request->query('department_id') : null;
        $scopeEmployeeIds = $request->attribute('scope_employee_ids');

        $result = $this->employees->paginateList(
            $paging['offset'],
            $paging['per_page'],
            is_string($search) ? $search : null,
            is_string($status) ? $status : null,
            $departmentId,
            is_array($scopeEmployeeIds) ? $scopeEmployeeIds : null
        );

        return $this->ok(
            $result['items'],
            'Employee list',
            Paginator::meta($result['total'], $paging['page'], $paging['per_page'])
        );
    }

    public function show(Request $request, array $params): array
    {
        $id = (int) ($params['id'] ?? 0);
        $employee = $this->employees->findWithDepartment($id);
        if ($employee === null) {
            throw new HttpException('Employee not found', 404, 'not_found');
        }
        return $this->ok($employee, 'Employee detail');
    }

    public function store(Request $request): array
    {
        $payload = Validator::validate($request->all(), [
            'employee_code' => ['required', 'string'],
            'full_name' => ['required', 'string'],
            'company_email' => ['required', 'email'],
            'hire_date' => ['required', 'date'],
            'phone_number' => ['string'],
            'status' => ['string'],
            'nationality_id' => ['integer'],
        ]);

        $authUser = $request->attribute('auth_user');
        $payload['created_by'] = (int) ($authUser['employee_id'] ?? 1);
        $payload['updated_by'] = (int) ($authUser['employee_id'] ?? 1);

        $id = $this->employees->create($payload);
        $created = $this->employees->findWithDepartment($id);
        return $this->created($created, 'Employee created');
    }

    public function update(Request $request, array $params): array
    {
        $id = (int) ($params['id'] ?? 0);
        $existing = $this->employees->find($id);
        if ($existing === null) {
            throw new HttpException('Employee not found', 404, 'not_found');
        }

        $payload = Validator::validate($request->all(), [
            'full_name' => ['string'],
            'company_email' => ['email'],
            'phone_number' => ['string'],
            'status' => ['string'],
            'hire_date' => ['date'],
            'nationality_id' => ['integer'],
        ]);

        $authUser = $request->attribute('auth_user');
        $payload['updated_by'] = (int) ($authUser['employee_id'] ?? 1);
        $this->employees->updateById($id, $payload);
        return $this->ok($this->employees->findWithDepartment($id), 'Employee updated');
    }

    public function destroy(Request $request, array $params): array
    {
        $id = (int) ($params['id'] ?? 0);
        $existing = $this->employees->find($id);
        if ($existing === null) {
            throw new HttpException('Employee not found', 404, 'not_found');
        }

        $this->employees->deleteById($id);
        return $this->ok(null, 'Employee deleted');
    }
}
